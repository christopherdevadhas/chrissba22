import { Component, OnInit } from '@angular/core';
import { SampleService } from './task-component.service';
@Component({
  selector: 'app-task-component',
  templateUrl: './task-component.component.html',
  styleUrls: ['./task-component.component.css'],
   providers: [ SampleService ]
})
export class TaskComponentComponent implements OnInit {
smpls:string[];
inputtext=null;
sample=null

clickAction()
{
	this.sample=this.inputtext
}
  constructor(private sm: SampleService) {
	this.smpls=this.sm.smpls
	  }

  ngOnInit() {
  }
  addMore()
  {
	  this.smpls.push(this.inputtext)
		this.inputtext=null;
}
}
