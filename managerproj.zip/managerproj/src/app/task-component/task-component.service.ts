export class SampleService{
smpls=['test task smpl1','test task smpl2', 'test task smpl3','test task smpl4'];
}