export class SampleService{
smpls=['test user smpl1','test user smpl2', 'test user smpl3','test user smpl4'];
}